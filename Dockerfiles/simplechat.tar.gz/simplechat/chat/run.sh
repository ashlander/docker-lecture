#!/bin/sh
export LD_LIBRARY_PATH=libs
./simplechat.wt  --docroot . --http-address 0.0.0.0 --http-port 8080
